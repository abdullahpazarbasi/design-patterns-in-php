#!/usr/bin/env bash

set -e
if [[ -f /.dockerenv ]]; then
    echo "You can not run this shell script from inside a docker container"
    exit 1
fi

cd "$(dirname "$0")"

if [[ `docker ps --format '{{.Names}}' | grep dpip-php` ]]; then
    docker-compose down
fi
