#!/usr/bin/env bash

set -e
if [[ -f /.dockerenv ]]; then
    echo "You can not run this shell script from inside a docker container"
    exit 1
fi

cd "$(dirname "$0")"

OPT=""
XDEBUG_PART="-dxdebug.remote_autostart=0"
FILTER_PART=""

for ARG in "$@"; do
  if [[ $OPT = "filter" ]]; then
      OPT=""
      FILTER_PART="--filter=${ARG}"
      continue
  fi
  if [[ $ARG = "-h" ]] || [[ $ARG = "--help" ]]; then
      echo "HELP:"
      echo "-h | --help : prints these lines"
      echo "--xdebug : activates xdebug"
      echo "--filter KEYWORD : filters by KEYWORD"
      exit 0
  fi
  if [[ $ARG = "--filter" ]]; then
      OPT="filter"
      continue
  fi
  if [[ $ARG = "--xdebug" ]]; then
      XDEBUG_PART="-dxdebug.remote_autostart=1"
      continue
  fi
done
if [[ $OPT = "filter" ]]; then
    echo "You must give the filter value"
    exit 1
fi

docker-compose exec php php $XDEBUG_PART ./vendor/bin/phpunit $FILTER_PART