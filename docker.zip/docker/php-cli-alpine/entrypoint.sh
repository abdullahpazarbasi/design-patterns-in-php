#!/usr/bin/env bash
php -v
composer -V
tail -f /dev/null